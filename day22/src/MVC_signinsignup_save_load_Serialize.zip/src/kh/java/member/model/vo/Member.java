package kh.java.member.model.vo;

import java.io.Serializable;

public class Member implements Serializable {
	private static final long serialVersionUID = 1037875606L;
	private String userId, userPwd, userName, phoneNumber;
	private int age;
	public Member() {}
	@Override
	public String toString() {
		return "\n���̵� : " + userId + "\n��й�ȣ : " + userPwd + "\n�̸� : "
				+ userName + "\n���� : " + age + "\n����ȣ  : " + phoneNumber + "\n\n" ;
	}
	public void setUserId(String userId) {this.userId = userId;}
	public String getUserId() {return userId;}
	public void setUserName(String userName) {this.userName = userName;}
	public String getUserName() {return userName;}
	public void setUserPwd(String userPwd) {this.userPwd = userPwd;}
	public String getUserPwd() {return userPwd;}
	public void setPhoneNumber(String phoneNumber) {this.phoneNumber = phoneNumber;}
	public String getPhoneNumber() {return phoneNumber;}
	public void setAge(int age) {this.age = age;}
	public int getAge() {return age;}
}
