package kh.java.member.controller;

import java.io.*;
import java.util.HashMap;

import kh.java.member.model.vo.Member;

public class MemberController {

	private HashMap<String, Member> hMap = new HashMap<String, Member>();
	private final String PATH = System.getProperty("user.home") + "/Desktop/MemberList.txt";

	public boolean memberJoin(Member m) {
		hMap.put(m.getUserId(), m);
		return false;
	}

	public boolean memberCheck(String userId) {
		if (hMap.containsKey(userId)) {
			return true;
		} else {
			return false;
		}
	}

	public Member memberSelect(String userId) {
		return hMap.get(userId);
	}

	public boolean memberModify(Member m) {
		hMap.put(m.getUserId(), m);
		return false;
	}

	public boolean memberDelete(String userId) {
		hMap.remove(userId);
		return false;
	}

	public void memberSave() {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PATH))) {
			oos.writeObject(hMap);
		} catch (IOException e) {
			System.out.print(e.getMessage());
		}
	}

	public boolean memberLoad() {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(PATH))) {
			hMap = (HashMap<String, Member>) (ois.readObject());
			return true;
		} catch (IOException e) {
			System.out.print("\n" + e.getMessage());
			return false;
		} catch (ClassNotFoundException e) {
			System.out.print("\n" + e.getMessage());
			return false;
		}
	}
}
