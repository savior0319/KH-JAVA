/*Controller*/
package student.controller;

import java.io.*;
import java.util.*;

import student.vo.Student;

public class StudentController {

	private ArrayList<Student> aList = new ArrayList<Student>();
	private final String PATH = System.getProperty("user.home") + "/Desktop/StudentList.txt";

	public boolean insertStudent(Student s) {
		aList.add(s);
		return true;
	}

	public ArrayList<Student> selectAll() {
		Collections.sort(aList);
		return aList;
	}

	public int searchStudent(int number) {
		boolean isChk = false;
		for (int i = 0; i < aList.size(); i++) {
			if (aList.get(i).getClassNumber() == number) {
				isChk = true;
				return i;
			}
		}
		if (isChk == false) {
			return -1;
		}
		return 0;
	}
	
	public void updateStudent(Student s, int index) {
		aList.set(index, s);
	}

	public void deleteStudent(int index) {
		aList.remove(index);
	}

	public Student selectOne(int index) {
		Student temp = aList.get(index);
		return temp;
	}

	public void saveStudent() {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PATH))){
			oos.writeObject(aList);
		}catch (IOException e) {
			System.out.print(e.getMessage());
		}
	}

	public boolean loadStudent() {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(PATH))){
			aList = (ArrayList<Student>)ois.readObject();
			return true;
		} catch (Exception e) {
			System.out.print("\n" + e.getMessage());
			return false;
		}
	}
}
