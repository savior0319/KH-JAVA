/*Value Object*/
package student.vo;

import java.io.Serializable;

public class Student implements Comparable<Student>, Serializable{
	private static final long serialVersionUID = 1037875606L;
	private String name, adress;
	private int age, classNumber;
	private double grade;
	public Student() {}
	@Override
	public String toString() 
	{ return classNumber + "\t" + name + "\t\t" + age + "\t\t" + adress + "\t\t" + grade; }
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public String getAdress() {return adress;}
	public void setAdress(String adress) {this.adress = adress;}
	public int getAge() {return age;}
	public void setAge(int age) {this.age = age;}
	public int getClassNumber() {return classNumber;}
	public void setClassNumber(int classNumber) {this.classNumber = classNumber;}
	public double getGrade() {return grade;}
	public void setGrade(double grade) {this.grade = grade;}
	@Override
	public int compareTo(Student o) { return this.classNumber - (o.classNumber); }
}
