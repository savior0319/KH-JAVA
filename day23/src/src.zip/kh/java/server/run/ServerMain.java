package kh.java.server.run;

import kh.java.server.socket.TCPServerSoket;

public class ServerMain {
	public static void main(String[] args) {
		new TCPServerSoket();
	}
}
