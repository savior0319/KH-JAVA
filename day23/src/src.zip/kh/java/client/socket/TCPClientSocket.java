package kh.java.client.socket;

import java.io.*;
import java.net.*;

public class TCPClientSocket {
	public TCPClientSocket() {
			 
		final int PORT = 5606;
		final String SERVER_IP = "localhost";
		Socket csk = null;
		try {
			csk = new Socket(SERVER_IP , PORT); 
			System.out.println("�������� ������ �Ǿ����ϴ�");
			InputStream in = csk.getInputStream(); 
			DataInputStream dis = new DataInputStream(in);
			String data = dis.readUTF();
			System.out.println(data);
			dis.close();
		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				csk.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
