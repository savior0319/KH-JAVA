package kh.java.client.run;

import kh.java.client.socket.TCPClientSocket;

public class ClientMain {
	public static void main(String[] args) {
		new TCPClientSocket();
	}
}
