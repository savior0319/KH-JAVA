/*Student Run*/
package student.run;

import student.view.StudentView;

public class Main {
	public static void main(String[] args) {
		new StudentView().mainMenu();
	}
}
