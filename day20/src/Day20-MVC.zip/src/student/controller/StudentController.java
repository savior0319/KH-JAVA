/*Student Controller*/
package student.controller;

import java.util.ArrayList;
import java.util.Collections;

import student.vo.Student;

public class StudentController {
	private ArrayList<Student> aList = new ArrayList<Student>();

	public StudentController() {}

	public boolean insertStudent(Student s) {
		return aList.add(s);
	}

	public ArrayList<Student> selectAll() {
		Collections.sort(aList);
		return aList;
	}

	public Student selectOne(int search) {
		Student temp = null;
		for(int i = 0; i < aList.size(); i++) {
			if(aList.get(i).getClassNumber() == search) {
				temp = aList.get(i);
			}
		}
		return temp; 
	}

	public void updateStudent(Student stu, Student s) {
		aList.set(aList.indexOf(stu), s);
	}

	public void deleteStudent(Student stu) {
		aList.remove(aList.indexOf(stu));
	}
}
