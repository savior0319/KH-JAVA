/*Student Value Object*/
package student.vo;

public class Student implements Comparable<Student>{
	private int classNumber, age;
	private String adress, name;
	private double grade;
	
	@Override
	public String toString() {
		return classNumber + "\t" + name + "\t\t" + age + "\t\t" + adress
				+ "\t\t" + grade;
	}

	public Student() {}

	public int getClassNumber() {return classNumber;}
	public void setClassNumber(int classNumber) {this.classNumber = classNumber;}
	public int getAge() {return age;}
	public void setAge(int age) {this.age = age;}
	public String getAdress() {return adress;}
	public void setAdress(String adress) {this.adress = adress;}
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public double getGrade() {return grade;}
	public void setGrade(double grade) {this.grade = grade;}

	@Override
	public int compareTo(Student o) {
		return this.classNumber - ((Student)(o)).classNumber;
	}
}
