/*Controller*/
package student.controller;

import java.util.*;

import student.vo.Student;

public class StudentController implements ControllerInterface {

	ArrayList<Student> aList = new ArrayList<Student>();

	@Override
	public boolean insertStudent(Student s) {
		aList.add(s);
		return true;
	}

	@Override
	public ArrayList<Student> selectAll() {
		Collections.sort(aList);
		return aList;
	}

	@Override
	public int searchStudent(int number) {
		boolean isChk = false;
		for (int i = 0; i < aList.size(); i++) {
			if (aList.get(i).getClassNumber() == number) {
				isChk = true;
				return i;
			}
		}
		if (isChk == false) {
			return -1;
		}
		return 0;
	}
	
	@Override
	public void updateStudent(int index, Student s) {
		aList.set(index, s);
	}

	@Override
	public void deleteStudent(int index) {
		aList.remove(index);
	}

	@Override
	public Student selectOne(int index) {
		Student temp = aList.get(index);
		return temp;
	}
}
