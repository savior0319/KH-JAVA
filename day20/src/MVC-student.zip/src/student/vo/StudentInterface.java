/*Value Object Interface*/
package student.vo;

public interface StudentInterface {
		public int getClassNumber();
		public void setClassNumber(int classNumber);
		public String getName();
		public void setName(String name);
		public int getAge();
		public void setAge(int age) ;
		public String getAdress() ;
		public void setAdress(String Adress); 
		public double getGrade();
		public void setGrade(double grade);
		@Override
		public String toString();
}
