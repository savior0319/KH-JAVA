package student.view;

public interface ViewInterface {

		public void mainMenu() ;

		public void deleteStudent();
		public void updateStudent();
		public void insertStudent();
		public void selectOne();
		public void selectAll();


}
