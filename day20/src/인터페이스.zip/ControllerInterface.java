package student.controller;

import java.util.ArrayList;

import student.vo.Student;

public interface ControllerInterface {

		public boolean insertStudent(Student s) ;

		public ArrayList<Student> selectAll() ;

		public int searchStudent(int number) ;

		public void updateStudent(Student s, int index) ;

		public void deleteStudent(int index) ;

		public Student selectOne(int index);

	}













}
