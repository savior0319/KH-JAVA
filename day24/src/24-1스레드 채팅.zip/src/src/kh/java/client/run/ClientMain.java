package src.kh.java.client.run;

import src.kh.java.client.socket.ClientChat;

public class ClientMain {
	public static void main(String[] args) {
		new ClientChat();
	}
}
