package src.kh.java.client.socket;

import java.io.*;
import java.net.*;
import java.util.*;

public class ClientChat implements Runnable {

	Scanner sc = new Scanner(System.in);
	final int PORT = 9999;
	final String IP = "localhost";
	Socket ssk = null;
	DataOutputStream dos = null;

	public ClientChat() {
		try {
			ssk = new Socket(IP, PORT);
			dos = new DataOutputStream(ssk.getOutputStream());
			new Thread(this).start();
			while (true) {
				String msg = sc.nextLine();
				if (msg.equals("exit")) {
					System.out.println("�� �����մϴ�");
					dos.writeUTF(msg);
					return;
				} else {
					dos.writeUTF(msg);
				}
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				ssk.close();
				dos.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	@Override
	public void run() {
		try (DataInputStream dis = new DataInputStream(ssk.getInputStream())) {
			while (true) {
				String temp = dis.readUTF();
				if (temp.equals("exit")) {
					System.out.println("\n�� �����մϴ�");
					return;
				} else
					System.out.println("[����] : " + temp);
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
