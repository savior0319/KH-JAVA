package src.kh.java.server.socket;

import java.io.*;
import java.net.*;
import java.util.*;

public class ServerChat implements Runnable {

	Scanner sc = new Scanner(System.in);
	final int PORT = 9999;
	ServerSocket ssk = null;
	Socket sck = null;
	DataOutputStream dos = null;
	
	public ServerChat() {
		try {
			System.out.println("�� Ŭ���̾�Ʈ ���� ������Դϴ�");
			ssk = new ServerSocket(PORT);
			sck = ssk.accept();
			System.out.println(sck.getInetAddress() + "�� ������ �����߽��ϴ�");
			dos = new DataOutputStream(sck.getOutputStream());
			dos.writeUTF("�� ä�� ������ �����ϼ̽��ϴ�");
			new Thread(this).start();
			while (true) {
				String msg = sc.nextLine();
				if (msg.equals("exit")) {
					System.out.println("�� �����մϴ�");
					dos.writeUTF(msg);
					return;
				} else {
					dos.writeUTF(msg);
				}
			}

		} catch (IOException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				sck.close();
				ssk.close();
				dos.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	@Override
	public void run() {
		try (DataInputStream dis = new DataInputStream(sck.getInputStream())) {
			while (true) {
				String temp = dis.readUTF();
				if (temp.equals("exit")) {
					System.out.println("\n�� �����մϴ�");
					return;
				} else
					System.out.println("[Ŭ���̾�Ʈ] : " + temp);
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
