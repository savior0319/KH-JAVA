package src.kh.java.server.run;

import src.kh.java.server.socket.ServerChat;

public class ServerMain {
	public static void main(String[] args) {
		new ServerChat();
	}
}
