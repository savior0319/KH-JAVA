package kh.java.run;

import kh.java.member.view.MemberView;

public class MemberRun {

	public static void main(String[] args) {
		new MemberView().mainMenu();
	}
}
