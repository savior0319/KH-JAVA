/*Main*/
package me.java.run;

import me.java.controller.StudentController;

public class RunMain {
	public static void main(String[] args) {
		StudentController sc = new StudentController();
		sc.start();
	}
}
