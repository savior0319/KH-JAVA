/*Model*/
package me.java.model.vo;

public class StudentData {
	private String name, addr;
	private int kor, eng, math;
	private char grade;
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public String getAddr() {return addr;}
	public void setAddr(String addr) {this.addr = addr;}
	public int getKor() {return kor;}
	public void setKor(int kor) {this.kor = kor;}
	public int getEng() {return eng;}
	public void setEng(int eng) {this.eng = eng;}
	public int getMath() {return math;}
	public void setMath(int math) {this.math = math;}
	public char getGrade() {return grade;}
	public void setGrade(char grade) {this.grade = grade;}
	public double getAvg() {return (getKor() + getEng() + getMath()) / (double) 3;}
}
