package me.java.model.vo;

public class BankData {
	private String name, birth, bankNumber;
	private int inMoney, outMoney, totalMoney;
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public String getBirth() {return birth;}
	public void setBirth(String birth) {this.birth = birth;}
	public String getBankNumber() {return bankNumber;}
	public void setBankNumber(String bankNumber) {this.bankNumber = bankNumber;}
	public int getInMoney() {return inMoney;}
	public void setInMoney(int inMoney) {this.inMoney = inMoney;}
	public int getOutMoney() {return outMoney;}
	public void setOutMoney(int outMoney) {this.outMoney = outMoney;}
	public int getTotalMoney() {return totalMoney;}
	public void setTotalMoney(int totalMoney) {this.totalMoney = totalMoney;}
}
