package me.java.controller;

public interface BkInterface {
	public void start();
	public void create();
	public void read();
	public void inputMoney(); 
	public void outMoney(); 
	public void sendMoney(); 
	public void update();
	public void delete();
	public void scrClean();
}
