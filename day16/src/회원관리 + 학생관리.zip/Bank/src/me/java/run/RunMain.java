package me.java.run;

import me.java.controller.Controller;

public class RunMain {
	public static void main(String[] args) {
		new Controller().start();
	}
}
