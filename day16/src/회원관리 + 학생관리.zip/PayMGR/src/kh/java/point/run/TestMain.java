/*Main*/
package kh.java.point.run;

import kh.java.point.controller.PntMgr;

public class TestMain {
	public static void main(String[] args) {
		PntMgr pm = new PntMgr();
		pm.start();
	}
}
