/*Super Class*/
package kh.java.point.model.vo;

public abstract class Grade {
	private String name, rank;
	private int point; 
	public Grade() {}
	public Grade(String name, String rank, int point) {
		setName(name); setRank(rank); setPoint(point);
	}
	public void setName(String name) {this.name = name;}
	public void setRank(String rank) {this.rank = rank;}
	public void setPoint(int point) {this.point = point;}
	public String getName() {return name;}
	public String getRank() {return rank;}
	public int getPoint() {return point;}
	public abstract double getRankPoint();
}
