/*Interface*/
package kh.java.point.controller;

public interface PntMgrInterface {
	public void insertData() ;
	public void start();
	public int searchData();
	public void modifyData();
	public void deleteData();
	public void printData();
}
