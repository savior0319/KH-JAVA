/*Sub class - Vip*/
package kh.java.point.model.vo;

public class Vip extends Grade{
	public Vip(String name, String rank, int point) {super(name, rank, point);}
	@Override
	public double getRankPoint() {return getPoint() * 0.5;}
}
