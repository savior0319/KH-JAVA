/*Sub Class - �����*/
package kh.java.point.model.vo;

public class Bronze extends Grade{
	public Bronze(String name, String rank, int point) 
	{super(name, rank, point);}
	@Override
	public double getInterest() 
	{return getPoint() * 0.01;}
}
