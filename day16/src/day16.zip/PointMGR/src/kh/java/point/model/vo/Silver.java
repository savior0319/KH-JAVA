/*Sub Class - �ǹ�*/
package kh.java.point.model.vo;

public class Silver extends Grade {
	public Silver(String name, String rank, int point) 
	{super(name, rank, point);}
	@Override
	public double getInterest() 
	{return getPoint() * 0.02;}
}
