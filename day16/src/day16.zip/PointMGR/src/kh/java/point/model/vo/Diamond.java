/*Sub Class - ���̾�*/
package kh.java.point.model.vo;

public class Diamond extends Grade{
	public Diamond(String name, String rank, int point) 
	{super(name, rank, point);}
	@Override
	public double getInterest() 
	{return getPoint() * 0.50;}
}
