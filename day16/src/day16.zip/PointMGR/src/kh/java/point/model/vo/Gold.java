/*Sub Class - ���*/
package kh.java.point.model.vo;

public class Gold extends Grade {
	public Gold(String name, String rank, int point) 
	{super(name, rank, point);}
	@Override
	public double getInterest() 
	{return getPoint() * 0.03;}
}
