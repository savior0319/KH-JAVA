/*Super Class*/
package kh.java.point.model.vo;

public abstract class Grade {
	private String name, rank;
	private int point;
	public Grade(String name, String rank, int point) {
		setName(name); setRank(rank); setPoint(point);
	}
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public String getRank() {return rank;}
	public void setRank(String rank) {this.rank = rank;}
	public int getPoint() {return point;}
	public void setPoint(int point) {this.point = point;}
	public abstract double getInterest();
}
