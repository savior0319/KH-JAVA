/*Interface*/
package me.java.controller;

public interface StdInterface {
	public void start();
	public int findIndex();
	public void stdInsert();
	public void stdView();
	public void stdModify();
	public void stdRemove();
	public void stdSearch();
	public void chkGrade();
}
