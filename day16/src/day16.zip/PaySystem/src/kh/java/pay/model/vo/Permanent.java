/*Sub Class - ������*/
package kh.java.pay.model.vo;

public class Permanent extends Salary{
	public Permanent(String name, String rank, int pay) 
	{super(name, rank, pay);}
	@Override
	public double getRankPay() 
	{return getPay();}
}
