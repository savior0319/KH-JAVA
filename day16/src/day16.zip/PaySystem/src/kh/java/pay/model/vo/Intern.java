/*Sub Class - ����*/
package kh.java.pay.model.vo;

public class Intern extends Salary{
	public Intern(String name, String rank, int pay)
	{super(name, rank, pay);}
	@Override
	public double getRankPay() 
	{return getPay() * 0.8;}
}
