/*Sub Class - �ð���*/
package kh.java.pay.model.vo;

public class PartTime extends Salary{
	private int hour;
	public PartTime(String name, String rank, int pay, int hour)
	{super(name, rank, pay);this.hour = hour;}
	@Override
	public double getRankPay() 
	{return getPay() * hour;}
}
