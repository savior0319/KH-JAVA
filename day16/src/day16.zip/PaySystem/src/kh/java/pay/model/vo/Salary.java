/*Super Class*/
package kh.java.pay.model.vo;

public abstract class Salary {
	private String name, rank;
	private double pay;
	public Salary(String name, String rank, int pay) 
	{setName(name); setRank(rank); setPay(pay);}
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public String getRank() {return rank;}
	public void setRank(String rank) {this.rank = rank;}
	public double getPay() {return pay;}
	public void setPay(double pay) {this.pay = pay;}
	public abstract double getRankPay();
}
